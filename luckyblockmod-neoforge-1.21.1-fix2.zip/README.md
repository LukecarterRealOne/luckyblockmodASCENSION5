# Lucky Block Ascension — NeoForge 1.21.1

This project is a source port of Lucky Block Ascension from Forge 1.20.1 to **NeoForge 1.21.1**. It targets **Java 21** and NeoForge **21.1.x**.

## Build with GitHub Actions

1. Keep `.github/workflows/build.yml` in the repository.
2. Upload the extracted project files to the repository root, or upload this source archive as `luckyblockmod-neoforge-1.21.1.zip`.
3. Open the **Actions** tab and run **Build Lucky Block (NeoForge 1.21.1)**.
4. When the workflow completes successfully, download the `luckyblockmod-neoforge-1.21.1` artifact. It contains the mod JAR.

The workflow uses Java 21 and Gradle 9.2.1. This repository contains source code, not a precompiled JAR. A successful Actions build is required before installing it in Minecraft.

## Local build

Use JDK 21 and Gradle 9.2.1, then run:

```bash
gradle --no-daemon clean build
```

The mod JAR is written to `build/libs/`.

## In game

Install Minecraft 1.21.1 with NeoForge 21.1.x, then place the built JAR in your instance's `mods` folder.

- `/give @s luckyblockmod:lucky_block`
- Press **G** to open the compact, paginated ability picker.
- Right-click casts the selected power; selection defaults to a random power.
- Sneak + right-click casts Omega Beam.
- Carrying the Lucky Block in the main inventory or offhand grants passive flight in Survival/Adventure at 0.10 flying speed (twice the vanilla creative default). Double-tap jump to fly. Previous flight settings are restored when the block leaves the inventory.

## Port details

- Replaced Forge `SimpleChannel` with NeoForge custom payloads and `StreamCodec`.
- Migrated registry access, deferred registration, lifecycle events, tick events, item tooltip signature, and `neoforge.mods.toml` metadata for 1.21.1.
- Preserved the 34 abilities, projected 4D Tesseract VFX, layered impact effects, passive flight, searchable Item Wish catalogue, ally commands, and server-side item validation.
- Particle bursts, rings, and screen effects are rate-limited to reduce visual clutter.

## Compatibility fixes from the first NeoForge build

The first GitHub Actions compilation exposed several 1.21.1 API differences. This revision addresses the reported errors:

- Use `getEntitiesOfClass(Entity.class, ...)` to avoid overloaded `getEntities` ambiguity.
- Read stack limits from an `ItemStack` in 1.21.1.
- Use the four-argument `Mob.finalizeSpawn` and modern `LargeFireball(Level, LivingEntity, Vec3, int)` constructor.
- Support both `SoundEvent` and `Holder<SoundEvent>` constants in the sound helper.
- Replace the removed `LivingAttackEvent` with NeoForge's cancellable `LivingIncomingDamageEvent`.
- Remove the removed `DistExecutor` calls; use `IPayloadContext.enqueueWork`, with a client-side gate for the GUI packet.
- Use `setRemainingFireTicks` for fire duration.

## Verification status

The reported compiler errors have been patched, and this bundle passed ZIP integrity, Java delimiter, JSON/TOML parse, workflow YAML parse, and checks for the old API patterns. A full Gradle compilation has **not** been completed in this environment because Gradle and the Minecraft/NeoForge dependencies are not available offline. The next GitHub Actions run is needed to verify compilation and reveal any further issues.


### Latest compile fix

This source archive includes fixes for NeoForge 1.21.1's private flight-speed field access and the updated `RenderGuiEvent.Post` API. Re-run the included GitHub Actions workflow after replacing the repository's source ZIP.
