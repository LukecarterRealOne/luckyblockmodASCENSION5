package com.lucky.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(LuckyBlockMod.MOD_ID)
public class LuckyBlockMod {
    public static final String MOD_ID = "luckyblockmod";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredItem<LuckyBlockItem> LUCKY_BLOCK = ITEMS.register(
            "lucky_block", () -> new LuckyBlockItem(new Item.Properties().stacksTo(1)));

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.literal("Lucky Block"))
                    .icon(() -> new ItemStack(LUCKY_BLOCK.get()))
                    .displayItems((params, output) -> output.accept(LUCKY_BLOCK.get()))
                    .build());

    public static final String PROTOCOL = "1";

    public LuckyBlockMod(IEventBus modBus) {
        ITEMS.register(modBus);
        TABS.register(modBus);
        modBus.addListener(this::addToTabs);
        modBus.addListener(ModNetworking::registerPayloads);
    }

    private void addToTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES
                || event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(LUCKY_BLOCK.get());
        }
    }
}
