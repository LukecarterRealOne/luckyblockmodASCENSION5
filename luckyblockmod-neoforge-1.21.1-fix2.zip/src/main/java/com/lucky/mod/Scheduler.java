package com.lucky.mod;

import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny server-tick scheduler used to animate the VFX over time. */
@EventBusSubscriber(modid = LuckyBlockMod.MOD_ID)
public class Scheduler {
    private static class Task {
        int delay;
        final Runnable action;

        Task(int delay, Runnable action) {
            this.delay = delay;
            this.action = action;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Task> QUEUE = new ArrayList<>();

    public static void later(int ticks, Runnable action) {
        QUEUE.add(new Task(Math.max(1, ticks), action));
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        LuckyBlockItem.captureSnapshots(event.getServer());
        TASKS.addAll(QUEUE);
        QUEUE.clear();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (--t.delay <= 0) {
                it.remove();
                try {
                    t.action.run();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        try {
            var server = event.getServer();
            server.getCommands().getDispatcher().execute("kill @e[tag=lbm_beam]", server.createCommandSourceStack());
        } catch (Exception ignored) {
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        TASKS.clear();
        QUEUE.clear();
    }
}
